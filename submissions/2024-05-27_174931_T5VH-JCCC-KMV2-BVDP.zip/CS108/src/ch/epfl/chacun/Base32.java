package ch.epfl.chacun;

/**
 * Class for handling Base32 encoding and decoding. The Base32 format uses
 * the characters A-Z and 2-7 to represent 5 bits of binary data per character.
 */
public class Base32 {
    // The Base32 alphabet for encoding and decoding
    public static final String ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

    // Prevent instantiation
    private Base32() {}

    /**
     * Validates if a string only contains valid Base32 characters.
     *
     * @return true if the string is valid Base32, false otherwise.
     */
    public static boolean isValid(String str) {
        return str.toUpperCase().chars().allMatch(c -> ALPHABET.indexOf(c) != -1);
    }

    /**
     * Encodes a value representing 5 bits (0-31) into a single Base32 character.
     *
     * @param value The value to encode, should be between 0 and 31.
     * @return A string containing a single Base32 character.
     */
    public static String encodeBits5(int value) {
        Preconditions.checkArgument(value >= 0);
        return String.valueOf(ALPHABET.charAt(value % 32));  // Ensure the value wraps around within the range of 0-31
    }

    /**
     * Encodes a value representing up to 10 bits (0-1023) into a two-character Base32 string.
     *
     * @param value The value to encode, should be between 0 and 1023.
     * @return A two-character Base32 string.
     */
    public static String encodeBits10(int value) {
        Preconditions.checkArgument(value >= 0 && value < 1023);
        int high = (value >> 5) & 31; // Extract the high 5 bits
        int low = value & 31;         // Extract the low 5 bits
        return STR."\{ALPHABET.charAt(high)}\{ALPHABET.charAt(low)}";
    }

    /**
     * Decodes a Base32 string (1 or 2 characters) into an integer.
     *
     * @param base32 A 1 or 2 character string representing a Base32 encoded number.
     * @return The decoded integer value.
     */
    public static int decode(String base32) {
        Preconditions.checkArgument(base32 != null && !base32.isEmpty() && base32.length() <= 2);
        base32 = base32.toUpperCase();
        int value = 0;
        for (int i = 0; i < base32.length(); i++) {
            int digit = ALPHABET.indexOf(base32.charAt(i));
            if (digit == -1) {
                throw new IllegalArgumentException(STR."Invalid Base32 character: \{base32.charAt(i)}");
            }
            value = (value << 5) + digit;
        }
        return value;
    }
}