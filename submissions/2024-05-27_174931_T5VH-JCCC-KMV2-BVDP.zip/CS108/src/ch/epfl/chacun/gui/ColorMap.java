package ch.epfl.chacun.gui;
import ch.epfl.chacun.PlayerColor;
import ch.epfl.chacun.Preconditions;
import javafx.scene.paint.Color;
public final class ColorMap {

    // J'ai mis un constructeur privé pour éviter les instanciations
    private ColorMap() {}
    public static Color fillColor(PlayerColor color) {
        return switch (color) {
            case RED -> Color.RED;
            case BLUE -> Color.BLUE;
            case GREEN -> Color.LIME;
            case YELLOW -> Color.YELLOW;
            case PURPLE -> Color.PURPLE;
        };
    }
    public static Color strokeColor(PlayerColor color) {
        return switch (color) {
            case YELLOW, GREEN ->
                    fillColor(color).deriveColor(0, 1, 0.6, 1); // 40% moins shiny que la couleur actuelle de remplissage
            default -> Color.WHITE; // Blanc pour les autres
        };
    }
}