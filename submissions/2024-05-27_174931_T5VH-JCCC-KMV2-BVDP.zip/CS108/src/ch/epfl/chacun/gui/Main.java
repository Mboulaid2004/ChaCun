package ch.epfl.chacun.gui;

import ch.epfl.chacun.*;
import javafx.application.Application;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.*;
import java.util.function.Consumer;
import java.util.random.RandomGeneratorFactory;
import java.util.stream.Collectors;

public class Main extends Application {

    public static void main(String[] args) {
        launch(args);
    }


    @Override
    public void start(Stage primaryStage) {
        // On analyse les arguments
        var parameters = getParameters();
        var unnamedArgs = parameters.getUnnamed();
        var namedArgs = parameters.getNamed();


        // On s'assure qu'il y a au moins 2 joueurs
        Preconditions.checkArgument(unnamedArgs.size() > 1 && unnamedArgs.size() <= 5);


        // On redéfinit les couleurs des joueurs
        List<PlayerColor> playerColors = Arrays.stream(PlayerColor.values()).sorted().toList();
        List<PlayerColor> players = new ArrayList<>();
        for (int i = 0; i < unnamedArgs.size(); i++) {
            players.add(playerColors.get(i));
        }

        // On prend la seed value si elle nous est donnée
        long seed = namedArgs.containsKey("seed") ? Long.parseUnsignedLong(namedArgs.get("seed")) : new Random().nextLong();

        // Hna je shuffle les tuiles en fonction de la seed donnée
        var randomGenerator = RandomGeneratorFactory.getDefault().create(seed);

        var tiles = new ArrayList<>(Tiles.TILES);

        Collections.shuffle(tiles, randomGenerator);
        var tilesByKind = tiles.stream().collect(Collectors.groupingBy(Tile::kind));

        // on recrée les tile decks
        var tileDecks = new TileDecks(
                tilesByKind.get(Tile.Kind.START),
                tilesByKind.get(Tile.Kind.NORMAL),
                tilesByKind.getOrDefault(Tile.Kind.MENHIR,List.of())
        );


        // On map le nom des joueurs à leur coleur respective
        var playerNames = new HashMap<PlayerColor, String>();
        for (int i = 0; i < unnamedArgs.size(); i++) {
            playerNames.put(players.get(i), unnamedArgs.get(i));
        }


        //Je crée le text maker
        var textMaker = new TextMakerFr(playerNames);


        // On initialise le game state
        var gameState = GameState.initial(players, tileDecks, textMaker);
        var gameState0 = new SimpleObjectProperty<>(gameState);
        var thisGamestate = gameState0.getValue();


        // on crée les observables
        var messageList = gameState0.map(gs -> gs.messageBoard().messages());
        var tileToPlace = gameState0.map(GameState::tileToPlace);
        var normalCount = gameState0.map(gs -> gs.tileDecks().deckSize(Tile.Kind.NORMAL));
        var menhirCount = gameState0.map(gs -> gs.tileDecks().deckSize(Tile.Kind.MENHIR));


        var text = gameState0.map(gs -> switch (gs.nextAction()) {
            case OCCUPY_TILE -> textMaker.clickToOccupy();
            case RETAKE_PAWN -> textMaker.clickToUnoccupy();
            default -> "";
        });

        var actions = new SimpleObjectProperty<List<String>>(new ArrayList<>());
        var tileToPlaceRotationP = new SimpleObjectProperty<>(Rotation.NONE);


        SimpleObjectProperty<Set<Occupant>> visibleOccupantsP = new SimpleObjectProperty<>(Set.of());

        visibleOccupantsP.bind(gameState0.map(g ->{
            Set<Occupant> potentialOccupants = new HashSet<>(g.board().occupants());
            if (g.nextAction() == GameState.Action.OCCUPY_TILE){
                potentialOccupants.addAll(g.lastTilePotentialOccupants());
            }
            return potentialOccupants;
        }));

        var tileIds = new SimpleObjectProperty<>(Set.<Integer>of());//ne doit pas etre vide


        // On définit les consumers
        Consumer<Occupant> occupantConsumer = e ->{
            if(gameState0.get().nextAction() == GameState.Action.OCCUPY_TILE){
                if(e == null) gameState0.set(gameState0.get().withNewOccupant(null));

                else{
                    PlacedTile tile = gameState0.get().board().tileWithId(Zone.tileId(e.zoneId()));
                    if(tile.placer() == gameState0.get().currentPlayer()){
                        ActionEncoder.StateAction stateAction = ActionEncoder.withNewOccupant(gameState0.get(), e);
                        actions.setValue(actionList(stateAction,actions));

                        gameState0.set(gameState0.get().withNewOccupant(e));
                    }
                }
            }

            if(gameState0.get().nextAction() == GameState.Action.RETAKE_PAWN){
                if(e == null) gameState0.set(gameState0.get().withOccupantRemoved(null));

                else{
                    PlacedTile tile = gameState0.get().board().tileWithId(Zone.tileId(e.zoneId()));
                    if(tile.placer() == gameState0.get().currentPlayer() && e.kind() == Occupant.Kind.PAWN){
                        ActionEncoder.StateAction stateAction = ActionEncoder.withOccupantRemoved(gameState0.get(), e);
                        actions.setValue(actionList(stateAction,actions));
                        gameState0.set(gameState0.get().withOccupantRemoved(e));
                    }
                }
            }
        };

        Consumer<String> actionConsumer = string -> {
            var result = ActionEncoder.decodeAndApply(gameState0.get(), string);
            if (result != null) {
                List<String> newList = new ArrayList<>(actions.get());
                newList.add(string);
                actions.set(newList);
                gameState0.set(result.gameState());
            }
        };

        Consumer<Rotation> rotationConsumer = e -> {
            tileToPlaceRotationP.set(tileToPlaceRotationP.getValue().add(e));
        };

        Consumer<Pos> positionConsumer = e -> {
            PlacedTile tile = new PlacedTile(tileToPlace.getValue()
                    ,gameState0.get().currentPlayer(),tileToPlaceRotationP.getValue(),e);

            if(gameState0.get().nextAction() == GameState.Action.PLACE_TILE && gameState0.get().board().canAddTile(tile)){
                ActionEncoder.StateAction stateAction = ActionEncoder.withPlacedTile(gameState0.get(),tile);
                actions.setValue(actionList(stateAction,actions));

                gameState0.set(gameState0.get().withPlacedTile(tile));
            }
        };

        // On crée les UI nodes
        var playersNode = PlayersUI.create(gameState0, textMaker);
        var messagesNode = MessageBoardUI.create(messageList, tileIds);
        var actionsNode = ActionUI.create(actions, actionConsumer);
        var decksNode = DecksUI.create(tileToPlace, normalCount, menhirCount, text, occupantConsumer);
        var boardNode = BoardUI.create(Board.REACH,gameState0,tileToPlaceRotationP,visibleOccupantsP,
                tileIds,rotationConsumer,positionConsumer,occupantConsumer);

        //On implemente le graphe de scene
        var bottomVbox = new VBox();
        bottomVbox.getChildren().add(actionsNode);
        bottomVbox.getChildren().add(decksNode);

        var rightBorderPane = new BorderPane(messagesNode, playersNode, null, bottomVbox, null);
        var finalBorderPane = new BorderPane(boardNode,null,rightBorderPane,null,null);

        gameState0.set(gameState.withStartingTilePlaced());


        primaryStage.setTitle("ChaCuN");
        primaryStage.setHeight(1080);
        primaryStage.setWidth(1440);
        primaryStage.setScene(new Scene(finalBorderPane));
        primaryStage.show();


    }

    private static List<String> actionList(ActionEncoder.StateAction stateActions, SimpleObjectProperty<List<String>> actionsOb){
        List<String> newActions = new ArrayList<>(actionsOb.get());
        newActions.add(stateActions.action());
        return newActions;
    }
}