package ch.epfl.chacun.gui;
import ch.epfl.chacun.PlayerColor;
import ch.epfl.chacun.Preconditions;
import javafx.scene.paint.Color;

/**
 * Interface utilisateur du plateau de jeu.
 *
 *@author Mehdi Boulaid (358117)
 * @author Adnane Jamil (356117)
 */
public final class ColorMap {

    private ColorMap() {}
    public static Color fillColor(PlayerColor color) {
        return switch (color) {
            case RED -> Color.RED;
            case BLUE -> Color.BLUE;
            case GREEN -> Color.LIME;
            case YELLOW -> Color.YELLOW;
            case PURPLE -> Color.PURPLE;
        };
    }
    public static Color strokeColor(PlayerColor color) {
        return switch (color) {
            case YELLOW, GREEN ->
                    fillColor(color).deriveColor(0, 1, 0.6, 1); // 40% moins shiny que la couleur actuelle de remplissage
            default -> Color.WHITE; // Blanc pour les autres
        };
    }
}